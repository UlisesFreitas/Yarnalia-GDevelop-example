# Yarnalia-GDevelop-example
Version 1.0.1
